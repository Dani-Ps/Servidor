package com.GestionAlumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
