package com.example.coches.entidad;
/**
 * Clase Enumeracion con los tipos de idiomas que hay
 */
public enum Idioma {
	ES,
	EN
}
