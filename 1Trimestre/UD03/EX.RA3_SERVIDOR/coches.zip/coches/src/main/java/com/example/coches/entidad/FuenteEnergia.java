package com.example.coches.entidad;
/**
 * Clase Enumeracion con los tipos de fuentes de energia que hay
 */
public enum FuenteEnergia {
	GASOLINA,
	DIESEL,
    ELECTRICO,
    HIBRIDO,
    HIDROGENO
}
